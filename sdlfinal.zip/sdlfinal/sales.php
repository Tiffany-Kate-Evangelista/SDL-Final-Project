<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> NEW </title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- custom style -->
        <link rel="stylesheet" href="style.css">
        <!-- for icons -->
        <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.3.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-9">
                    <div class="searchInputContainer">
                        <input type="text" placeholder="Search Product...">
                    </div>
                    <div class="searchResultContainer">
                        <div class="row">
                            <div class="col-4">
                                <div class="productResultContainer">
                                    <img src="images/yakult.png" alt="yakult">
                                    <div class="productInfoContainer">
                                        <div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p class="productName">Yakult</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="productPrice">P 12.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="productResultContainer">
                                    <img src="images/yakult.png" alt="yakult">
                                    <div class="productInfoContainer">
                                        <div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p class="productName">Yakult</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="productPrice">P 12.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="productResultContainer">
                                    <img src="images/yakult.png" alt="yakult">
                                    <div class="productInfoContainer">
                                        <div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p class="productName">Yakult</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="productPrice">P 12.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="productResultContainer">
                                    <img src="images/yakult.png" alt="yakult">
                                    <div class="productInfoContainer">
                                        <div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p class="productName">Yakult</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="productPrice">P 12.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="productResultContainer">
                                    <img src="images/yakult.png" alt="yakult">
                                    <div class="productInfoContainer">
                                        <div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p class="productName">Yakult</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="productPrice">P 12.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="productResultContainer">
                                    <img src="images/yakult.png" alt="yakult">
                                    <div class="productInfoContainer">
                                        <div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <p class="productName">Yakult</p>
                                                </div>
                                                <div class="col-md-6">
                                                    <p class="productPrice">P 12.00</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                <div class="col-3 posOrderContainer">
                    <div class="pos_header">
                        <div class="setting">
                            <a href="javascript:void(0);"><i class="fi fi-sr-settings"></i></a>
                        </div>
                        <p class="logo"> R&R </p>
                        <p class="timeAndDate">May 24, 2024 12:00 PM</p>
                    </div>
                </div>
            </div>
        </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    </body>
</html>