<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CREDITS</title>
    <link rel="stylesheet" href="inventorystyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="menu" id="menu">
        <div class="menu-content">
            <h2>MENU</h2>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="inventory.php">INVENTORY</a></li>
                <li><a href="credits.php">CREDITS</a></li>
                <li><a href="summary-report.php">SUMMARY REPORT</a></li>
            </ul>
        </div>
    </div>
    <div class="container" id="main-container">
        <header>
            <div class="logo">
                <img src="logo.png" alt="Logo">
            </div>
            <div class="title">
                <h1>INVENTORY</h1>
                <p>Sari-Sari Store Management: Cash Register, Inventory, and Credit Tracking System with Real-time Updates and Automated Order Processing</p>
            </div>
        </header>
        <main>
            <div class="buttons-container">
                <div class="buttons">
                    <button class="add"> <a href="addcustomer.php"> ADD CUSTOMER </a></button>
                    <button class="edit"><a href="editcustomer.php"> EDIT CUSTOMER</a></button>
                    <button class="remove"><a href="removecustomer.php"> REMOVE CUSTOMER</a></button>
                </div>
                <i class="fa fa-exclamation-triangle caution-sign" aria-hidden="true"></i>
                <input type="search" id="search" placeholder="Search...">
            </div>
            <section class="table">
                <table class="labels">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>CUSTOMER ID</th>
                            <th>CUSTOMER NAME</th>
                            <th>PHONE NUMBER</th>
                            <th>TRANSACTION DATE</th>
                            <th>DUE DATE</th>
                            <th>BALANCE</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $servername = "localhost";
                        $username = "root"; // replace with your MySQL username
                        $password = ""; // replace with your MySQL password
                        $dbname = "sdl_project";

                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Query to fetch customers
                        $sql = "SELECT * FROM customers";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row['id'] . "</td>";
                                echo "<td>" . $row['customer_id'] . "</td>";
                                echo "<td>" . $row['name'] . "</td>";
                                echo "<td>" . $row['contact_information'] . "</td>";
                                echo "<td>" . ($row['transaction_date'] ? $row['transaction_date'] : '') . "</td>";
                                echo "<td>" . ($row['due_date'] ? $row['due_date'] : '') . "</td>";
                                echo "<td>P" . number_format($row['current_credit'], 2) . "</td>";
                                echo "<td>" . ($row['current_credit'] > 0 ? 'UNPAID' : 'PAID') . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8'>No customers found</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>
    <button class="menu-toggle" id="menu-toggle">☰</button>

    <footer>
        <div class="foot">
            <p>&copy; 2024 Group 6. All rights reserved.</p>
        </div>
    </footer>

    <script src="homepagescript.js"></script>
</body>
</html>
