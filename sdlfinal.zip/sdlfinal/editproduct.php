<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Product Interface</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    
    .container {
        max-width: 600px;
        margin: 20px auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    h1 {
        text-align: center;
    }
    
    form {
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }
    
    input[type="text"],
    input[type="number"],
    input[type="date"] {
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100%;
        margin-bottom: 10px;
    }
    
    input[type="text"][readonly] {
        background-color: #f4f4f4; /* Change background color of read-only input */
        cursor: not-allowed; /* Change cursor to indicate that the field is not editable */
    }
    
    input[type="submit"] {
        padding: 10px 20px;
        font-size: 16px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
    }
</style>
</head>
<body>
    <div class="container">
        <h1>Edit Product</h1>
        <form id="editProductForm">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" placeholder="Enter product name" required>
            
            <label for="productId">Product ID:</label>
            <input type="text" id="productId" placeholder="Enter product ID" readonly required>

            <label for="categoryId">Category ID:</label>
            <input type="text" id="categoryId" placeholder="Enter category ID" required>

            <label for="dateAdded">Date Added:</label>
            <input type="date" id="dateAdded" required>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" placeholder="Enter quantity" required>

            <label for="criticalIndicator">Critical Indicator (Minimum Quantity to Restock):</label>
            <input type="number" id="criticalIndicator" placeholder="Enter critical quantity" min="0" required>

            <label for="price">Price:</label>
            <input type="number" id="price" placeholder="Enter price" step="0.01" required>

            <input type="submit" value="Save Changes">
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById('editProductForm').style.display = 'block'; // Show the form when the page loads
        });
    </script>
</body>
</html>
