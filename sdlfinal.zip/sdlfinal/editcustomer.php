<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Customer Interface</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    
    .container {
        max-width: 600px;
        margin: 20px auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    h1 {
        text-align: center;
    }
    
    form {
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }
    
    input[type="text"],
    input[type="tel"],
    input[type="date"],
    input[type="number"],
    select {
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100%;
        margin-bottom: 10px;
    }
    
    input[type="submit"] {
        padding: 10px 20px;
        font-size: 16px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
    }
</style>
</head>
<body>
    <div class="container">
        <h1>Edit Customer</h1>
        <form id="editCustomerForm">
            <label for="customerId">Customer ID:</label>
            <input type="text" id="customerId" placeholder="Enter customer ID" required disabled>
            
            <label for="customerName">Customer Name:</label>
            <input type="text" id="customerName" placeholder="Enter customer name" required>

            <label for="phoneNumber">Phone Number:</label>
            <input type="tel" id="phoneNumber" placeholder="Enter phone number (11 digits)" required>

            <label for="transactionDate">Transaction Date:</label>
            <input type="date" id="transactionDate" required>

            <label for="dueDate">Due Date:</label>
            <input type="date" id="dueDate" required readonly>

            <label for="balance">Balance:</label>
            <input type="number" id="balance" placeholder="Enter balance" step="0.01" min="0" required>

            <label for="status">Status (Paid or Unpaid):</label>
            <select id="status" required>
                <option value="">Select status</option>
                <option value="paid">Paid</option>
                <option value="unpaid">Unpaid</option>
            </select>

            <input type="submit" value="Edit Customer">
        </form>
    </div>

    <script>
        document.getElementById('editCustomerForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            alert('Customer information edited successfully!');
        });

        document.getElementById('transactionDate').addEventListener('change', function() {
            var transactionDate = new Date(document.getElementById('transactionDate').value);
            var dueDate = new Date(transactionDate.getTime() + 7 * 24 * 60 * 60 * 1000); // Set due date as a week after the selected transaction date
            var formattedDueDate = dueDate.toISOString().split('T')[0]; // Convert due date to YYYY-MM-DD format
            document.getElementById('dueDate').value = formattedDueDate;
        });

        
        document.getElementById('phoneNumber').addEventListener('input', function() { // Validate phone number input
            var phoneNumberInput = document.getElementById('phoneNumber').value;
            var numericPhoneNumber = phoneNumberInput.replace(/\D/g, ''); // Remove any non-numeric characters
            var limitedPhoneNumber = numericPhoneNumber.slice(0, 11);
            document.getElementById('phoneNumber').value = limitedPhoneNumber; // Update the input value
        });
    </script>
</body>
</html>
