<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Remove Customer Interface</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    
    .container {
        max-width: 600px;
        margin: 20px auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    
    h1 {
        text-align: center;
    }
    
    form {
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
    }
    
    input[type="text"],
    input[type="tel"],
    input[type="date"],
    input[type="number"],
    select {
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100%;
        margin-bottom: 10px;
    }
    
    input[type="submit"] {
        padding: 10px 20px;
        font-size: 16px;
        background-color: #ff6347; /* Change to red color for delete action */
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 100%;
    }
</style>
</head>
<body>
    <div class="container">
        <h1>Remove Customer</h1>
        <form id="removeCustomerForm">
            <label for="customerId">Customer ID:</label>
            <input type="text" id="customerId" placeholder="Enter customer ID to remove" required>
            
            <input type="submit" value="Remove Customer">
        </form>
    </div>

    <script>
        document.getElementById('removeCustomerForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission
            alert('Customer removed successfully!');  // To remove customer logic here
        });
    </script>
</body>
</html>
