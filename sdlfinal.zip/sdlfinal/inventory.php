<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <link rel="stylesheet" href="inventorystyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="menu" id="menu">
        <div class="menu-content">
            <h2>MENU</h2>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="inventory.php">INVENTORY</a></li>
                <li><a href="credits.php">CREDITS</a></li>
                <li><a href="summary.php">SUMMARY REPORT</a></li>
            </ul>
        </div>
    </div>
    <div class="container" id="main-container">
        <header>
            <div class="logo">
                <img src="logo.png" alt="Logo">
            </div>
            <div class="title">
                <h1>INVENTORY</h1>
                <p>Sari-Sari Store Management: Cash Register, Inventory, and Credit Tracking System with Real-time Updates and Automated Order Processing</p>
            </div>
        </header>
        <main>
            <div class="buttons-container">
                <div class="buttons">
                    <button class="add"><a href="addproduct.php">ADD PRODUCT</a></button>
                    <button class="edit"><a href="editproduct.php">EDIT PRODUCT</a></button>
                    <button class="remove"><a href="removeproduct.php">REMOVE PRODUCT</a></button>
                </div>
                <i class="fa fa-exclamation-triangle caution-sign" aria-hidden="true"></i>
                <input type="search" id="search" placeholder="Search...">
            </div>
            <section class="table">
                <table class="labels">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>CATEGORY ID</th>
                            <th>PRODUCT ID</th>
                            <th>PRODUCT NAME</th>
                            <th>QUANTITY</th>
                            <th>PRICE</th>
                            <th>STOCK LEVEL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Database connection details
                        $servername = "localhost"; // Usually 'localhost'
                        $username = "root"; // Replace with your database username
                        $password = ""; // Replace with your database password
                        $dbname = "product_db"; // Replace with your database name

                        // Create connection to product_db
                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch data from the products table
                        $sql = "SELECT * FROM biscuits";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . (isset($row["ID"]) ? htmlspecialchars($row["ID"]) : " ") . "</td>";
                                echo "<td>" . (isset($row["CATEGORY_ID"]) ? htmlspecialchars($row["CATEGORY_ID"]) : " ") . "</td>";
                                echo "<td>" . (isset($row["PRODUCT_ID"]) ? htmlspecialchars($row["PRODUCT_ID"]) : " ") . "</td>";
                                echo "<td>" . (isset($row["PRODUCT_NAME"]) ? htmlspecialchars($row["PRODUCT_NAME"]) : " ") . "</td>";
                                echo "<td>" . (isset($row["QUANTITY"]) ? htmlspecialchars($row["QUANTITY"]) : " ") . "</td>";
                                echo "<td>" . (isset($row["PRICE"]) ? htmlspecialchars($row["PRICE"]) : " ") . "</td>";
                                echo "<td>" . (isset($row["STOCK_LEVEL"]) ? htmlspecialchars($row["STOCK_LEVEL"]) : " ") . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No products found</td></tr>";
                        }

                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>
</body>